<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NexmoController extends MainController
{
    

    public static function newOrder(){
        $basic = new \Nexmo\Client\Credentials\Basic('89e14e93', 'fGHJ2kmgjQngJ6lS');
        $client = new \Nexmo\Client($basic);

        $message = $client->message()->send([
            'to' => '972549082678',
            'from' => 'Vonage APIs',
            'text' => 'Hello from Vonage SMS API'
        ]);
    }


    public static function orderUpdated(){
        $basic = new \Nexmo\Client\Credentials\Basic('89e14e93', 'fGHJ2kmgjQngJ6lS');
        $client = new \Nexmo\Client($basic);

        $message = $client->message()->send([
            'to' => '972549082678',
            'from' => 'Vonage APIs',
            'text' => 'Hello from Vonage SMS API'
        ]);
    }


    public static function security(){
        $basic = new \Nexmo\Client\Credentials\Basic('89e14e93', 'fGHJ2kmgjQngJ6lS');
        $client = new \Nexmo\Client($basic);

        $message = $client->message()->send([
            'to' => '972549082678',
            'from' => 'Vonage APIs',
            'text' => 'Hello from Vonage SMS API'
        ]);
    }
}
