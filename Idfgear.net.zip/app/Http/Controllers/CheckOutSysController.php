<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CheckOutSysController extends MainController
{
    // public function index(Request $request){
    //     self::$dtv['page_title'] .= "Check Out";
    //     dd($request);
    //     return view('pay', self::$dtv);
    // }

    // public function post(Request $request){
    //     dd($request);
    // }
}
