

<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Order Form</h1>
</div>

              
<div class="row">
    <div class="col-lg-6">
      <form id="add-menu-form" action="<?php echo e(url('cms/orders/' . $item->id)); ?>" method="POST" autocomplete="off" novalidate="novalidate" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">

        
          <div class="form-group">
            <label for="title">Orderd By
            </label>
          <input disabled value="<?php echo e($order->first()->name); ?>" type="text" name="title" id="title" class="form-control origin-filed">
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
          </div>

          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Items Orderd</th>
              </tr>
            </thead>
            <tbody>
            <tr>
            <td>
              <ul>
                <?php $__currentLoopData = unserialize($item->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                    <b><?php echo e($item['name']); ?></b>,
                    <b>Price: </b> $<?php echo e($item['price']); ?>

                    <b>Quantity: </b> <?php echo e($item['quantity']); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </td>
      
            </tr>
            </tbody>
          </table>


          <div class="form-group">
            <label for="title">Paid?
            </label>
            <?php
                //dd($order->first()->paid)

                if($order->first()->paid == "0"){
                  $order->first()->paid = "No";
                } elseif ($order->first()->paid == "1"){
                  $order->first()->paid = "Yes";
                } else {
                  $order->first()->paid;
                }
            ?>
          <input disabled value="<?php echo e($order->first()->paid); ?>" type="text" name="title" id="title" class="form-control origin-filed">
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
          </div>


        <br>
          <input type="submit" name="submit" value="Update Product" id="submit" class="btn btn-primary mb-2">
          <a href="<?php echo e(url('cms/orders')); ?>" class="btn btn-light ml-3">Cancel</a>

        </form>
    </div>
</div>

<br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear.net\resources\views/cms/order_edit.blade.php ENDPATH**/ ?>