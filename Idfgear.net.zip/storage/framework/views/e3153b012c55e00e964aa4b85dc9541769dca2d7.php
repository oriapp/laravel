<?php
    $num = 0;
?>


<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
</div>

              
<div class="row">
  <div class="col-12">
      <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>ID</th>
              <th>User Name</th>
              <th>Phone</th>
              <th>Header</th>
              <th>Header</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $num++;
                if($num > 3) continue;
            ?>
            <tr>
              <td><?php echo e($order->id); ?></td>
              <td><?php echo e($users->where('user_id', '=', $order->user_id)->first()->name); ?></td>
              <td>lorem</td>
              <td>dolor</td>
              <td>sit</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $num++;
                if($num > 3) continue;
            ?>
            <tr>
              <td><?php echo e($order->id); ?></td>
              <td><?php echo e($users->where('user_id', '=', $order->user_id)->first()->name); ?></td>
              <td>lorem</td>
              <td>dolor</td>
              <td>sit</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear.net\resources\views/cms/dashboard.blade.php ENDPATH**/ ?>