

<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit Menu Form</h1>
</div>

              
<div class="row">
    <div class="col-lg-6">
    <form id="add-menu-form" action="<?php echo e(url('cms/menu/' . $item->id )); ?>" method="POST" autocomplete="off" novalidate="novalidate">
          <?php echo csrf_field(); ?>
          <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="item_id" value="<?php echo e($item->id); ?>">
          <div class="form-group">
            <label for="link"><code>*</code> Menu Link
            </label>
          <input value="<?php echo e($item->link); ?>" type="text" name="link" id="link" class="form-control origin-filed">
          <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
          </div>

          <div class="form-group">
            <label for="url"><code>*</code> URL
              <small><i>(Friendly URL - Lower case, numbers, -)</i></small>
            </label>
            <input value="<?php echo e($item->url); ?>" type="text" name="url" id="url" class="form-control target-filed">
            <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
          </div>

          <div class="form-group">
            <label for="title"><code>*</code> Page Link
            </label>
            <input value="<?php echo e($item->title); ?>" type="text" name="title" id="title" class="form-control">
            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
          </div>

          <input type="submit" name="submit" value="Update Menu" id="submit" class="btn btn-primary">
          <a href="<?php echo e(url('cms/menu')); ?>" class="btn btn-light ml-3">Cancel</a>

        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/cms/menu_edit.blade.php ENDPATH**/ ?>