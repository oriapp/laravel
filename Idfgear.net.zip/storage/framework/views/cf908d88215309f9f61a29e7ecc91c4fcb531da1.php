[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xxa\htdocs\laravel\Idfgear\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>