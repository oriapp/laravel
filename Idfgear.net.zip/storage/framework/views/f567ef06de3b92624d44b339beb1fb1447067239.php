<?php
    use App\Product;
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    
</div>

<!-- index css -->
<link rel="stylesheet" href="<?php echo e(asset('css/indexPage.css')); ?>">



<?php $__env->startComponent('components.indexBanner'); ?>
<?php $__env->slot('title_one'); ?> Idfgear <?php $__env->endSlot(); ?>
<?php $__env->slot('title_two'); ?> Professional equipment <?php $__env->endSlot(); ?>
<?php $__env->slot('title_tree'); ?> AirSoft And Tools <?php $__env->endSlot(); ?>
<?php $__env->slot('title_four'); ?> Israeli tactical outdoor gear <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginal61ce07690fdb712c6967777f29a9fcd1a38d9353)): ?>
<?php $component = $__componentOriginal61ce07690fdb712c6967777f29a9fcd1a38d9353; ?>
<?php unset($__componentOriginal61ce07690fdb712c6967777f29a9fcd1a38d9353); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<hr>


<div class="container body mt-3">
<div class="child-page-listing">

  <h2 class="<?php echo e(__('btn.text_align')); ?>"><?php echo e(__('text.brands')); ?></h2>

  <div class="grid-container">

    <article id="3685" class="location-listing">

      <a class="location-title" href="<?php echo e(asset('search/masada')); ?>">
                    <!--San Francisco-->                       </a>

      <div class="location-image">
        <a href="#">
        <img class="img" width="300" height="169" src="<?php echo e(asset('/images/home/masada .png')); ?>" alt="masada">      </a>

      </div>

    </article>

    <article id="3688" class="location-listing">

      <a class="location-title" href="<?php echo e(asset('search/Lior-pig')); ?>">
                    <!--San Francisco-->                      </a>

      <div class="location-image">
        <a href="#">
                        <img class="img" width="300" height="169" src="<?php echo e(asset('/images/home/Lior-pig.png')); ?>" alt="london">    </a>

      </div>

    </article>

    <article id="3691" class="location-listing">

      <a class="location-title" href="<?php echo e(asset('search/511')); ?>">
                    <!--San Francisco-->                        </a>

      <div class="location-image">
        <a href="#">
                        <img class="img" width="300" height="169" src="<?php echo e(asset('/images/home/Logo-511_Tactical.svg.png')); ?>" alt="new york">    </a>

      </div>

    </article>

    <article id="3694" class="location-listing">

      <a class="location-title" href="#">
                    <!--San Francisco-->                       </a>

      <div class="location-image">
        <a href="#">
                        <img class="img" width="300" height="169" src="https://cdn.shopify.com/s/files/1/0228/2169/9620/files/DT_brands-01_2_1_2048x.jpg?v=1589454910" alt="cape town">  </a>

      </div>

    </article>

    <article id="3697" class="location-listing">

      <a class="location-title" href="#">
                    <!--San Francisco-->                     </a>

      <div class="location-image">
        <a href="#">
                        <img class="img" width="300" height="169" src="https://cdn.shopify.com/s/files/1/0228/2169/9620/files/DT_brands-06_4_1_2048x.jpg?v=1590048913" alt="beijing">      </a>

      </div>

    </article>

    <article id="3700" class="location-listing">

      <a class="location-title" href="#">
                    <!--San Francisco-->                       </a>

      <div class="location-image">
        <a href="#">
                        <img class="img" width="300" height="169" src="https://cdn.shopify.com/s/files/1/0228/2169/9620/files/DT_brands-04_2_2048x.jpg?v=1589454996" alt="paris">                  
                    </a>
      </div>

    </article>

  </div>
  <!-- end grid container -->

</div>
</div>

<style>
  /* position dots up a bit */
.flickity-page-dots {
  bottom: -22px;
}
/* dots are lines */
.flickity-page-dots .dot {
  height: 4px;
  width: 40px;
  margin: 0;
  border-radius: 0;
}
</style>


<hr>

<?php if(Session::get("product_view")): ?>
<div class="container mt-3">
<h1 class="mb-3 text-center"><?php echo e(__('text.rhf-container')); ?></h1>
  <div class="carousel" data-flickity='{ "fullscreen": true, "lazyLoad": 1, "autoPlay": 3000, "pauseAutoPlayOnHover": false, "selectedAttraction": 0.01, "friction": 0.40, "wrapAround": true}'>
    <?php $__currentLoopData = $last_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    
    <div class="carousel-cell">
    <h3 onclick="window.location.href =('<?php echo e(asset('search/' .$item[0]->purl .'')); ?>');"><?php echo e($item[0]->ptitle); ?>:&nbsp;&nbsp;&nbsp;  </h3>
    <img class="carousel-cell-image" 
        data-flickity-lazyload="<?php echo e(asset('/images/'.$item[0]->pimage)); ?>" />
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<br><br>
    
<?php else: ?>

<div class="container mt-3">

  <?php
    $last_view = Product::fiveItems();
  ?>

  <h1 class="mb-3 text-center"><?php echo e(__('text.products_you_may_like')); ?></h1>
    <div class="carousel" data-flickity='{ "fullscreen": true, "lazyLoad": 1, "autoPlay": 3000, "pauseAutoPlayOnHover": false, "selectedAttraction": 0.01, "friction": 0.40, "wrapAround": true}'>
      <?php $__currentLoopData = $last_view; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
      
      <div class="carousel-cell">
      <h3><?php echo e($item->ptitle); ?>:&nbsp;&nbsp;&nbsp;  </h3>
      <img class="carousel-cell-image" 
          data-flickity-lazyload="<?php echo e(asset('/images/'.$item->pimage)); ?>" />
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <br><br>

<?php endif; ?>



<link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>">
<div class="container">
  <hr>
  <br><br>
  <h1 class="<?php echo e(__('btn.text_align')); ?>"><?php echo e(__('text.new_products')); ?></h1>
  <?php if(Product::newItems() ): ?>
  
          <?php $__currentLoopData = Product::newItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <div class="card-img" style="background-image:url(<?php echo e(asset('images/' . $item->pimage)); ?>);">
      <div class="overlay">
        <div class="overlay-content">
          <a href="<?php echo e(url('shop/'.$item->url . '/'. $item->purl)); ?>"><?php echo e(__('text.view_product')); ?></a>
        </div>
      </div>
    </div>
    
    <div class="card-content">
      <a href="<?php echo e(url('shop/'.$item->url . '/'. $item->purl)); ?>">
        <h2><?php echo e($item->ptitle ?? 'Error'); ?></h2>
        <p><?php echo $item->in_short ?? null; ?></p>
      <h7 class="float-right"><?php echo e(date('d/m/y H:i:s', strtotime($item->updated_at))); ?></h7>
      </a>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  <br><br>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear\resources\views/home.blade.php ENDPATH**/ ?>