
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> <?php echo e(__('text.languages_select')); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(__('text.languages_description')); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-lg-6">
            <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="language">* Select Language</label>
                    <select class="form-control" name="Language" id="language">
                      <option <?php if(Session::get('language') == "en"): ?> selected="selected" <?php endif; ?> value="en" name="en" id="en">English</option>
                      <option <?php if(Session::get('language') == "he"): ?> selected="selected" <?php endif; ?> value="he" name="he" id="he">Hebrew</option>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('language')); ?></span>
                  </div>

                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/language.blade.php ENDPATH**/ ?>