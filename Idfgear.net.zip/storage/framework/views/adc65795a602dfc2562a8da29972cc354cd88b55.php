
<?php $__env->startSection('content'); ?>
<div class="container">
<?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> <?php echo e(__('text.categories_title')); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(__('text.categories_description')); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>">

    





<div class="container">
<?php if($categories->count() ): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card">
	<div class="card-img" style="background-image:url(<?php echo e(asset('images/' . $category->image)); ?>);">
		<div class="overlay">
			<div class="overlay-content">
				<a href="<?php echo e(url('shop/'.$category->url)); ?>">View Project</a>
			</div>
		</div>
	</div>
	
	<div class="card-content">
		<a href="<?php echo e(url('shop/'.$category->url)); ?>">
			<h2><?php echo e($category->title); ?></h2>
			<p><?php echo $category->description; ?></p>
		</a>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear.net\resources\views/categories.blade.php ENDPATH**/ ?>