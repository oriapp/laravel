<div class="row">
    <div class="col-12 mt-3 text-center">
    <h1 class="display-4"><?php echo e($title); ?></h1>
        <p><?php echo e($description); ?></p>
    </div>
</div><?php /**PATH C:\xxa\htdocs\laravel\Idfgear\resources\views/components/page_hader.blade.php ENDPATH**/ ?>