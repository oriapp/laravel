
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> Pay Form <?php $__env->endSlot(); ?>
<?php $__env->slot('description'); ?> Billing details <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="alert alert-danger" role="alert">
        <?php echo __('text.signup_warning'); ?>

      </div>
    <div class="row">
        <div class="col-lg-6">
            <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="form-group">

                <div class="form-group">
                    <label for="address"><code>*</code> <?php echo e(__('text.address')); ?></label>
                    <input value="<?php echo e(old('address')); ?>" type="address" name="address" id="address" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('address')); ?> </span>
                </div>


                <div class="form-row">
                    <div class="form-group col-md-6">
                    <label for="city"><code>*</code> <?php echo e(__('text.city')); ?></label>
                    <input value="<?php echo e(old('city')); ?>" type="city" name="city" id="city" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('city')); ?> </span>
                    </div>


                    <div class="form-group col-md-4">
                    <label for="state"><code>*</code> <?php echo e(__('text.state')); ?></label>
                    <input value="<?php echo e(old('state')); ?>" type="state" name="state" id="state" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('state')); ?> </span>
                </div>

                <div class="form-group col-md-2">
                    <label for="zip"><code>*</code> <?php echo e(__('text.zip')); ?></label>
                <input value="<?php echo e(old('zip')); ?>" type="zip" name="zip" id="zip" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('zip')); ?> </span>
                </div>
                </div>


                <div class="form-group">
                    <label for="phone"><code>*</code> <?php echo e(__('text.phone')); ?></label>
                    <input value="<?php echo e(old('phone')); ?>" type="phone" name="phone" id="phone" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('phone')); ?> </span>
                </div>

                <div class="form-group">
                    <label for="email"><code>*</code> <?php echo e(__('text.email')); ?></label>
                    <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('email')); ?> </span>
                </div>
                
                <button type="submit" class="mb-3 btn btn-primary"><?php echo e(__('text.signup')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear.net\resources\views/pay.blade.php ENDPATH**/ ?>