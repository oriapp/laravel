<?php

         function amount($id){
           $pro = DB::table('products as p')
         ->where('p.id', '=', $id)
         ->select('p.amount')
         ->get();
         
         return (int) filter_var($pro, FILTER_SANITIZE_NUMBER_INT);
         }
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> Cart Page <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(__('text.about_description')); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <?php if(!Cart::isEmpty()): ?>
        <div class="col-12">
            <table class="table table-bordered table-responsive-sm">
                <thead>
                    <tr>
                        <th>Product:</th>
                        <th class="text-center">Quantity:</th>
                        <th>Price:</th>
                        <th>Sub Total:</th>
                        <th>In our stock:</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['name']); ?></td>
                            <td class="text-center">
                            <button data-pid="<?php echo e($item['id']); ?>" data-op="minus" type="button" href="#" class="update-cart-btn btn btn-outline-primary btn-sm"><i class="fas fa-minus-circle"></i></button>
                            <input size="1" id="quantity" class="text-center" type="text" value="<?php echo e($item['quantity']); ?>">
                                <button data-pid="<?php echo e($item['id']); ?>" data-qu="<?php echo e(amount($item['id'])); ?>" data-op="plus" type="button" href="#" class="update-cart-btn btn btn-outline-primary btn-sm"><i class="fas fa-plus-circle"></i></button>
                            </td>
                            <td><?php echo e($item['price']); ?></td>
                            <td>$<?php echo e($item['quantity'] * $item['price']); ?></td>
                            <td id="<?php echo e($item['id']); ?>-instock"><?php echo e(amount($item['id'])); ?></td>
                            
                        <td><a class="text-danger remove-from-cart-btn" href="<?php echo e(url('shop/cart?removeItem='.$item['id'])); ?>"><i class="fas fa-trash-alt"></i></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <p>
                <b>Total In Cart: </b> $<?php echo e(Cart::getTotal()); ?>

                <span class="float-right">
                    <a href="#" class="btn btn-light clear-cart-btn">
                        Clear Cart
                        
                    </a>
                </span>
            </p>
            <p>
            <a href="<?php echo e(url('shop/check-out')); ?>" class="btn btn-primary btn-lg">Buy Now!</a>
            </p>
            
        </div>
        <?php else: ?>
        <div class="col-12 text-center">
            <p><i>No Items In Cart!</i></p>
        </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear.net\resources\views/cart.blade.php ENDPATH**/ ?>