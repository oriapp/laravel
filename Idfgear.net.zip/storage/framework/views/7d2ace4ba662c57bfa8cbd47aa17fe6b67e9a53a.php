 
<?php $__env->startSection('content'); ?>
<div class="container">
<?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> <?php echo e(__('text.product_title', ['product_title' => $products[0]->title])); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(null); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <style>
      

  .card-product:after {
    content: "";
    display: table;
    clear: both;
    visibility: hidden; }
  .card-product .price-new, .card-product .price {
    margin-right: 5px; }
  .card-product .price-old {
    color: #999; }
  .card-product .img-wrap {
    border-radius: 3px 3px 0 0;
    overflow: hidden;
    position: relative;
    height: 220px;
    text-align: center; }
    .card-product .img-wrap img {
      max-height: 100%;
      max-width: 100%;
      object-fit: cover; }
      
      .card-product .info-wrap {
    overflow: hidden;
    padding: 15px;
    border-top: 1px solid #eee; }
  .card-product .action-wrap {
    padding-top: 4px;
    margin-top: 4px; }
  .card-product .bottom-wrap {
    padding: 15px;
    border-top: 1px solid #eee; }
  .card-product .title {
    margin-top: 0; }
    </style>

    


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">




<div class="row">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
<div class="col-md-4">
	<figure class="card card-product">
		<div class="img-wrap"><img src="<?php echo e(asset('images/'.$product->pimage)); ?>"></div>
		<figcaption class="info-wrap">
				<h4 class="title <?php echo e(__('btn.text_align')); ?>"><?php echo e($product->ptitle); ?></h4>
				<p class="desc <?php echo e(__('btn.text_align')); ?>"><?php echo e($product->in_short); ?></p>
				
		</figcaption>
		<div class="bottom-wrap">
    <h6 class="<?php echo e(__('btn.text_align')); ?>"><?php echo e(__('text.left_in_stock', ['amount' => $product->amount])); ?></h6>
        <hr>
    <a href="<?php echo e(url('shop/'.$product->url.'/'.$product->purl)); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('text.view_product')); ?></a>	
			<div class="price-wrap h5">
        <?php
            if($product->old_price == "0.00"){
              $product->old_price = null;
            } else {
              $product->old_price = "$$product->old_price";
            }
        ?>
      <span class="price-new">$<?php echo e($product->price); ?></span> <del class="price-old"><?php echo e($product->old_price); ?></del>
			</div> <!-- price-wrap.// -->
		</div> <!-- bottom-wrap.// -->
	</figure>
</div> <!-- col // -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <!-- row.// -->



</div> 
<!--container.//-->


<div class="d-flex justify-content-center">
<div class="mt-4">
  <?php echo e($products->appends(['sort' => 'title'])->render()); ?>

</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear\resources\views/products.blade.php ENDPATH**/ ?>