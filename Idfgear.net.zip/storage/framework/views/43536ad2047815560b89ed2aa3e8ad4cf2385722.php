
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> <?php echo e(__('text.signup_title')); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(__('text.signup_description')); ?> <a href="<?php echo e(url('user/signin')); ?>"><?php echo e(__('text.signin')); ?></a> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="alert alert-danger" role="alert">
        <?php echo __('text.signup_warning'); ?>

      </div>
    <div class="row">
        <div class="col-lg-6">
            <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name"><code>*</code> <?php echo e(__('text.name')); ?></label>
                    <input value="<?php echo e(old('name')); ?>" type="text" name="name" id="name" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('name')); ?> </span>
                </div>
                <div class="form-group">
                    <label for="email"><code>*</code> <?php echo e(__('text.email')); ?></label>
                    <input value="<?php echo e(old('')); ?>" type="email" name="email" id="email" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('email')); ?> </span>
                </div>
                <div class="form-group">
                    <label for="password"><code>*</code> <?php echo e(__('text.password')); ?></label>
                    <input type="password" name="password" id="password" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('password')); ?> </span>
                </div>

                

                <div class="form-group">
                <label for="phone"><code>*</code> <?php echo e(__('text.phone')); ?></label>
                    <input value="<?php echo e(old('phone')); ?>" type="text" name="phone" id="phone" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('phone')); ?> </span>
                </div>


                <div class="form-group">
                    <label for="language"><code>*</code> <?php echo e(__('text.select_language')); ?></label>
                    <select class="form-control" name="Language" id="language">
                      <option value="en" name="en" id="en">English</option>
                      <option value="he" name="he" id="he">Hebrew</option>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('language')); ?></span>
                  </div>
                  

                <button type="submit" class="mb-3 btn btn-primary"><?php echo e(__('text.signup')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear\resources\views/signup.blade.php ENDPATH**/ ?>