<?php

return [
    'float' => 'float-right',
    'text_align' => 'text-right',
];