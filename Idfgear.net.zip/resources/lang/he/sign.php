<?php

return [
    'home' => 'בית',
    'email' => 'אימייל',
    'username' => 'שם מלא',
    'phone' => 'מספר אלפון',
    'password' => 'סיסמא',
    'login_here' => 'היכנס כאן',

    'register' => 'הירשם',

    'signup_title' => 'רישום לקוח חדש כאן',

    'already_member' => 'כבר חבר?',


    'signup_description' => 'הירשם וקבל את חשבונך בחנות הנשק בחינם, מהירה וקלה.',

    'signup_mandetory' => 'שדות עם * הם חובה',

    'signup_agree_1' => 'הסכמתי ל',
    'signup_agree_2' => 'תנאים',
    'signup_agree_3' => 'המסדירים את השימוש בחנות הנשק',

];