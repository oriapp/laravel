<?php

return [
    'float' => 'float-left',
    'text_align' => 'text-left',
];