<?php

return [
    'home' => 'Home',
    'email' => 'Email',
    'username' => 'Username',
    'phone' => 'Phone',
    'password' => 'Password',
    'login_here' => 'Login Here',

    'register' => 'Register',

    'signup_title' => 'New Customer Register Here',

    'already_member' => 'Already a member?',


    'signup_description' => 'Register got your account with weapon store is free,quick and easy.',

    'signup_mandetory' => 'Fields with * are mandatory',

    'signup_agree_1' => 'I agreed to the',
    'signup_agree_2' => 'Terms and Conditions',
    'signup_agree_3' => 'governing the use of weapon store',

];