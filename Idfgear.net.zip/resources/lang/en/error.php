<?php

return [
    '404' => 'Not Found',
];