<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>

  @component('components.whatsapp')
  @slot('number') 972528262490 @endslot
  @endcomponent

<div class="">
    <center>
    <div class="mt-3 jumbotron text-center">
        <h1 class="display-3">Thank You!</h1>
        <p class="lead"><strong>Your Order Has Benn Placed!</strong> <br> We will call you in the next 48 hours to complete your order and to make sure all the details provided here.</p>
        <hr>
        <p>
          Having trouble? <p>Contact us via whatsapp: +972 52-826-2490</p>
        </p>
        <p class="lead">
          <a class="btn btn-primary btn-sm" href="/" role="button">Continue to homepage</a>
        </p>
      </div>
    </center> 
</div>

</body>
</html>