<div class="row">
    <div class="col-12 mt-3 text-center">
    <h1 class="display-4">{{$title}}</h1>
        <p>{{$description}}</p>
    </div>
</div>