<?php
    use App\Categorie;
    $caregories = Categorie::all();
?>

<!doctype html>
<html lang="he">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <title><?php echo e($page_title ?? ''); ?></title>
  <script>let BASE_URL = "<?php echo e(url('')); ?>/";</script>

  
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  

  

  

  </head>
  <body>
    <?php echo $__env->make('notify::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo notifyJs(); ?>
        <?php echo notifyCss(); ?>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
            <a class="navbar-brand text-white" href="<?php echo e(url('')); ?>"><i class="fas fa-wind"></i> Soft</a>
            
            <a class="nav-link text-white" href="<?php echo e(url('shop/cart')); ?>">
            <?php if(! Cart::isEmpty()): ?>
            <div class="total-in-cart"><?php echo e(Cart::getTotalQuantity()); ?></div>
            <?php endif; ?>
                <i class="fas fa-shopping-cart"></i>
              </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">

            <li class="nav-item">
                <a class="nav-link text-white" href="<?php echo e(url('shop')); ?>">Shop</a>
              </li>
              <?php if(!empty($menu)): ?>
              <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo e(url($menu_item->url)); ?>"><?php echo e($menu_item->link); ?></a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </ul>
          <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
              <a class="nav-link text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="far fa-flag"></i>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="<?php echo e(url('flag/language')); ?>"> <?php echo e(__('text.language')); ?> </a>
                <?php if(Session::has('user_id')): ?>
                
                  <a class="dropdown-item" href="<?php echo e(url('user/profile')); ?>"> <?php echo e(__('text.edit_profile')); ?> </a>
                <?php endif; ?>
            </li>

            <?php if(!Session::has('user_id')): ?>
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo e(url('user/signin')); ?>"> <?php echo e(__('text.signin')); ?> </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="<?php echo e(url('user/signup')); ?>"> <?php echo e(__('text.signup')); ?> </a>
              </li>
              <?php else: ?>
              <?php if(Session::get('is_admin')): ?>
              <li class="nav-item">
                <a class="nav-link text-white" href="<?php echo e(url('cms/dashboard')); ?>"> <?php echo e(__('text.admin_dashboard')); ?> </a>
              </li>
              <?php endif; ?>
              <li class="nav-item">
                <a class="nav-link text-white" href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a>
                
              </li>
              <li class="nav-item">
                  <a class="nav-link text-white" href="<?php echo e(url('user/logout')); ?>"> <?php echo e(__('text.logout')); ?> </a>
                </li>
              <?php endif; ?>
          </ul>
        </div>
    </div>
      </nav>
    </header>
    <main style="min-height: 850px;">
    <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="bg-dark p-2 text-white">
    <footer class="page-footer font-small mdb-color lighten-3 pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Content -->
        <h5 class="font-weight-bold text-uppercase mb-4">idfgear</h5>
        <p class="p-footer">Here you can use rows and columns to organize your footer content.</p>
        <p class="p-footer">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit amet numquam iure provident voluptate
          esse
          quasi, veritatis totam voluptas nostrum.</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Links -->
        <h5 class="font-weight-bold text-uppercase mb-4">Categories <i class="fas fa-link"></i> </h5>

        <ul class="list-unstyled">
        <?php $__currentLoopData = $caregories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <p>
            <a class="text-white" href="#!"><?php echo e($categorie->title); ?></a>
          </p>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="font-weight-bold text-uppercase mb-4">Address <i class="fas fa-map-marker-alt"></i> </h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <i class="fas fa-home mr-3"></i> New York, NY 10012, US</p>
          </li>
          <li>
            <p>
              <i class="fas fa-envelope mr-3"></i> info@example.com</p>
          </li>
          <li>
            <p>
              <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
          </li>
          <li>
        </ul>

      </div>

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

        <!-- Social buttons -->
        <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>

        <!-- Facebook -->
        <a type="button" class="btn-floating btn-fb">
          <i class="fab fa-facebook-f"></i>
        </a>
        <!-- Twitter -->
        <a type="button" class="btn-floating btn-tw">
          <i class="fab fa-twitter"></i>
        </a>
        <!-- Google +-->
        <a type="button" class="btn-floating btn-gplus">
          <i class="fab fa-google-plus-g"></i>
        </a>
        <!-- Dribbble -->
        <a type="button" class="btn-floating btn-dribbble">
          <i class="fab fa-dribbble"></i>
        </a>

      </div>
      <a class="btn-floating btn-dribbble">
      <img style="max-width: 40% !important; height: auto;" class="rounded mx-auto d-block float-left" src="<?php echo e(asset('images/Powered-By-PayPal-Logo.png')); ?>">
      </a>
    </div>


  </div>

  <div class="footer-copyright text-center py-3">&copy; <?php echo e(date('Y')); ?> Copyright:
    <a href="http://about-rcn.me/"> Ori Applebaum</a>
  </div>

</footer>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <?php if(Session::has('sm')): ?>
    <script>
      toastr.options.positionClass = 'toast-bottom-center'
    toastr.success("<?php echo e(Session::get('sm')); ?>");
    </script>
    <?php endif; ?>

    <?php if(Session::has('em')): ?>
    <script>
      toastr.options.positionClass = 'toast-bottom-center'
    toastr.error("<?php echo e(Session::get('em')); ?>");
    </script>
    <?php endif; ?>

    
  <script src="<?php echo e(asset('js/script.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/master.blade.php ENDPATH**/ ?>