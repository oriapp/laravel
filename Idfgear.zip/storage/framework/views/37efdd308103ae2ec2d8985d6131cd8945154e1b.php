<?php
    if($user->language == 'he'){
      $user->language = 'Hebrew';
    } else if ($user->language = 'en'){
      $user->language = 'English';
    }
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> <?php echo e(__('text.editp_title')); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e(__('text.home_description')); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
</div>

<h1 align="center">edit this profile</h1>



<div class="container">    
    <div class="jumbotron">
      <div class="row">
          <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
              <img src="https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png" alt="stack photo" class="img">
          </div>
          <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
              <div class="container" style="border-bottom:1px solid black">
                <h2><?php echo e($user->name); ?></h2>
              </div>
                <hr>
              <ul class="container details">
                <li><p><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span>Phone: <?php echo e($user->phone ?? 'Could not find'); ?></p></li>
                <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span>Email: <?php echo e($user->email); ?></p></li>
              <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Address: <?php echo e($user->address); ?> <?php echo e($user->city); ?> <?php echo e($user->state); ?></p></li>
              <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Primary Language: <?php echo e($user->language); ?></p></li>
              <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Created At: <?php echo e($user->created_at); ?></p></li>
              </ul>
          </div>
      </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/edit_profile.blade.php ENDPATH**/ ?>