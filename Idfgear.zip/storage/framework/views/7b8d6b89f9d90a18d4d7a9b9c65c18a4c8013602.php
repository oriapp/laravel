
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> Phone verify <?php $__env->endSlot(); ?>
<?php $__env->slot('description'); ?> verification id <?php echo e($verification_id); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-lg-6">
            <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="code"><code>*</code> code</label>
                    <input type="code" name="code" id="code" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('code')); ?> </span>
                </div>
                <button type="submit" class="btn btn-primary">submit</button>
                <?php if(!empty($verify_error)): ?>
            <span class="text-danger"><?php echo e($verify_error); ?></span>
            <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/phoneverify.blade.php ENDPATH**/ ?>