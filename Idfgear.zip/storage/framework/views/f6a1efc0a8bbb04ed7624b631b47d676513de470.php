
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php $__env->startComponent('components.page_hader'); ?>
    <?php $__env->slot('title'); ?> Pay Now! <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> Billing details <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <?php if(session('error') || session('success')): ?>
   <p class="<?php echo e(session('error') ? 'error':'success'); ?>">
    <?php echo e(session('error') ?? session('success')); ?>

   </p>
   <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-6">
            <form action="<?php echo e(route('create-payment')); ?>" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name"><code>*</code> Full Name</label>
                    <input value="<?php echo e(old('name')); ?>" type="text" name="name" id="name" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('name')); ?> </span>
                </div>
                <div class="form-group">
                    <label for="company"><code>*</code> Company name (optional)</label>
                    <input value="<?php echo e(old('company')); ?>" type="company" name="company" id="company" class="form-control">
                    <span class="text-danger"> <?php echo e($errors->first('company')); ?> </span>
                </div>
                

                

                
                  

                <button type="submit" class="mb-3 btn btn-primary">Pay & Place order</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\Idfgear\resources\views/check_out.blade.php ENDPATH**/ ?>