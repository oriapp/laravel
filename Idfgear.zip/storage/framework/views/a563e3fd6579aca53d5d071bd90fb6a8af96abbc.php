 
<?php $__env->startSection('content'); ?>
<div class="container">
<?php $__env->startComponent('components.page_hader'); ?>
    
    <?php $__env->slot('title'); ?> <?php echo e($product->ptitle); ?> <?php $__env->endSlot(); ?>
    <?php $__env->slot('description'); ?> <?php echo e($product->brand); ?> <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a)): ?>
<?php $component = $__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a; ?>
<?php unset($__componentOriginalf3682dbe7eb26f130049011f21e6e5dffe64602a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row"> 
        <div class="col-7 my-5">
          <div class="card">
            <div class="header">
            <h3><?php echo e($product->ptitle); ?></h3>
            </div>
          <img src="<?php echo e(asset('images/'.$product->pimage)); ?>" class="card-img-top">
            <div class="card-body">
            <p><?php echo $product->particle; ?></p>
            <p><b><?php echo e(__('text.price_on_site')); ?> <b>$</b><?php echo e($product->price); ?></b></p>
            <p class="<?php echo e(__('btn.float')); ?>">
              
              <?php if(!Cart::get($product->id)): ?>
              <?php if($product->amount): ?>
            <button data-pid="<?php echo e($product->id); ?>" class="btn btn-success add-to-cart-btn">
              <i class="fas fa-cart-plus"></i> <?php echo e(__('text.add_to_cart')); ?>

              </button>
              <?php else: ?>
              <button class="btn btn-danger">
                out of stock!
                </button>
              <?php endif; ?>
              <?php else: ?>
              <button class="btn btn-success" disabled="disabled">
                In Cart!
              </button>
              <?php endif; ?>
              
              <a href="<?php echo e(url('shop/cart')); ?>" class="btn btn-primary ml-2">
                <?php echo e(__('text.go_to_cart')); ?>

              </a>
            </p>
            </div>
          </div>
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xxa\htdocs\laravel\laravel\resources\views/product_detailes.blade.php ENDPATH**/ ?>